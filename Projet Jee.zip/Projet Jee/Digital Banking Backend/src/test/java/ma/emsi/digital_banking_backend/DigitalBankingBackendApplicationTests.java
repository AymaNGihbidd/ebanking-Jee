package ma.emsi.digital_banking_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigitalBankingBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
