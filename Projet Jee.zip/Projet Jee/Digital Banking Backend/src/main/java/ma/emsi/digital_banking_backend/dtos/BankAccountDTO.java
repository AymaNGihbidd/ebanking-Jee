package ma.emsi.digital_banking_backend.dtos;

import lombok.Data;

@Data
public class BankAccountDTO {
    private String type;
}