package ma.emsi.digital_banking_backend.enums;

public enum UserRole {
    ADMIN,
    USER,
}
