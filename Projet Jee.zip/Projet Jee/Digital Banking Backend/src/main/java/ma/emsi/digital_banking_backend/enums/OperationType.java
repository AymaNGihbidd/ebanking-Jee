package ma.emsi.digital_banking_backend.enums;

public enum OperationType {
    DEBIT, CREDIT
}
