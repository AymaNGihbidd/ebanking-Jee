package ma.emsi.digital_banking_backend.enums;

public enum AccountStatus {
    CREATED, ACTIVATED, SUSPENDED
}
